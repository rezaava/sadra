<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IntroController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ServicesController;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\BlogPostController;
use App\Http\Controllers\QuoteController;
use App\Http\Controllers\JoinController;
use App\Http\Controllers\RepresentativeController;
use App\Http\Controllers\SubmitPortfolioController;
use App\Http\Controllers\LoginController;

Route::get('/', [IntroController::class, 'index'])->name('intro');
Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/about', [AboutController::class, 'index'])->name('about');
Route::get('/services', [ServicesController::class, 'index'])->name('services');
Route::get('/products', [ProductsController::class, 'index'])->name('products');
Route::get('/product', [ProductController::class, 'index'])->name('product');
Route::get('/blog', [BlogController::class, 'index'])->name('blog');
Route::get('/blog-post', [BlogPostController::class, 'index'])->name('blog-post');
Route::get('/quote', [QuoteController::class, 'index'])->name('quote');
Route::get('/join', [JoinController::class, 'index'])->name('join');
Route::get('/representative', [RepresentativeController::class, 'index'])->name('representative');
Route::get('/submit-portfolio', [SubmitPortfolioController::class, 'index'])->name('submit-portfolio');
Route::get('/login', [LoginController::class, 'index'])->name('login');

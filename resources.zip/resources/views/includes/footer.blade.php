<footer>
            <div class="wrap">
                <div class="footer-top">
                    <div class="footer-brand">
                        <div class="brand-name-fa">صدرا</div>
                        <p>استودیوی طراحی بسته‌بندی صدرا؛ همراه برندها از ایده تا تولید.</p>
                    </div>
                    <div class="footer-cols">
                        <div class="footer-col">
                            <h4>نقشه سایت</h4>
                            <a href="{{ route('home') }}#why">چرا ما</a>
                            <a href="{{ route('about') }}">درباره ما</a>
                            <a href="{{ route('home') }}#services">خدمات</a>
                            <a href="{{ route('products') }}">محصولات</a>
                            <a href="{{ route('home') }}#work">نمونه‌کارها</a>
                        </div>
                        <div class="footer-col">
                            <h4>شبکه‌های اجتماعی</h4>
                            <a href="#">اینستاگرام</a>
                            <a href="#">لینکدین</a>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <span>© ۱۴۰۴ صدرا. تمامی حقوق محفوظ است.</span>
                    <span class="en">SADRA.</span>
                </div>
            </div>
        </footer>
<button class="to-top" id="toTop" aria-label="بازگشت به بالا">
            <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
            >
                <path d="M12 19V5M5 12l7-7 7 7"/>
            </svg>
        </button>
